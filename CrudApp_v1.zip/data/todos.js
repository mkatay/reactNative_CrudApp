export const data=[
    {
        id:1,
        title:'Bankot felhívni',
        completed:false
    },
     {
        id:2,
        title:'Hétvégi síelés megtervezése',
        completed:false
    },
     {
        id:3,
        title:'Értekezlet kedden 14 órától',
        completed:false
    },
     {
        id:4,
        title:'Takarítás',
        completed:false
    },
     {
        id:5,
        title:'Bevásárlás Aldi',
        completed:false
    },
     {
        id:6,
        title:'Tankolás',
        completed:false
    },
     {
        id:7,
        title:'Könyvtári könyvet visszavinni',
        completed:false
    },
]